package mapper;

public interface CategoryMapper {
	String selectCategoryName(int id);
}
